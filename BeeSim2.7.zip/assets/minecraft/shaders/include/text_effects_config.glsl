



TEXT_EFFECT(16, 16, 16) {
    apply_iterating_movement(1,1.3);
    override_text_color(rgb(255, 255, 255));
    override_shadow_color(rgb(75, 75, 75));
}

TEXT_EFFECT(32, 32, 32) {
    override_text_color(rgb(165, 185, 232));
    apply_thin_outline(rgb(71, 123, 245));



    remove_text_shadow();
}

TEXT_EFFECT(31, 98, 255) {
    override_text_color(rgb(98, 98, 222));
    apply_shaking_movement();
    apply_outline(rgb(56, 56, 156));
}

TEXT_EFFECT(240, 192, 229) {
    remove_text_shadow();
    apply_gradient(rgb(240, 230, 237), rgb(235, 148, 211));
}


TEXT_EFFECT(224, 163, 230) {
    override_text_color(rgb(255, 247, 133));
    apply_iterating_movement(1,2);
    apply_fade(rgb(255,255,255),0.1);
    apply_thin_outline(rgb(238, 167, 60));
    remove_text_shadow();
}

TEXT_EFFECT(255, 199, 43) {
    override_text_color(rgb(255, 199, 43));
    remove_text_shadow();
    apply_thin_outline(rgb(222, 148, 0));
    apply_shimmer();
}

TEXT_EFFECT(199, 185, 199) {
    override_text_color(rgb(204, 204, 204));
    remove_text_shadow();
    apply_thin_outline(rgb(141, 141, 141));
    apply_shimmer();
}

TEXT_EFFECT(158, 103, 40) {
    override_text_color(rgb(158, 103, 40));
    remove_text_shadow();
    apply_thin_outline(rgb(77, 48, 15));
    apply_shimmer();
}

TEXT_EFFECT(48, 48, 48) {
    override_text_color(rgb(247, 246, 148));
    remove_text_shadow();
    apply_thin_outline(rgb(247, 144, 0));
}

TEXT_EFFECT(64, 64, 64) {
    override_text_color(rgb(189, 36, 69));
    remove_text_shadow();
    apply_growing_movement();
    apply_outline(rgb(79, 9, 20));
}

TEXT_EFFECT(80, 80, 80) {
    override_text_color(rgb(255, 255, 255));
    remove_text_shadow();
    apply_thin_outline(rgb(75, 75, 75));
}

TEXT_EFFECT(96, 96, 96) {
    apply_iterating_movement(1,0.5);
    remove_text_shadow();
    override_text_color(rgb(247, 246, 148));
    apply_thin_outline(rgb(247, 144, 0));
}

TEXT_EFFECT(112, 112, 112) {

    remove_text_shadow();
    override_text_color(rgb(255, 255, 255));
}




//RARE
TEXT_EFFECT(253, 237, 237) {
    apply_gradient(rgb(163, 163, 163), rgb(237, 237, 237));
    apply_shimmer(1,1);
}
TEXT_EFFECT(237, 237, 237) {
    apply_gradient(rgb(163, 163, 163), rgb(237, 237, 237));
}

//EPIC
TEXT_EFFECT(243, 232, 170) {
    apply_gradient(rgb(245, 197, 140), rgb(255, 232, 170));
    apply_shimmer(1,1);
}
TEXT_EFFECT(255, 232, 170) {
    apply_gradient(rgb(245, 197, 140), rgb(255, 232, 170));
}
//LEGENDARY
TEXT_EFFECT(190, 239, 233) {
    apply_gradient(rgb(110, 229, 239), rgb(152, 247, 237));
    apply_shimmer(1,1);
}
TEXT_EFFECT(184, 239, 233) {
    apply_gradient(rgb(110, 229, 239), rgb(152, 247, 237));
}

//MYTHIC
TEXT_EFFECT(222, 104, 237) {
    apply_gradient(rgb(198, 173, 240), rgb(232, 173, 240));
    apply_shimmer(1,1);
}
TEXT_EFFECT(238, 104, 237) {
    apply_gradient(rgb(198, 173, 240), rgb(232, 173, 240));
}

//Event
TEXT_EFFECT(216, 240, 188) {
    apply_gradient(rgb(134, 222, 122), rgb(197, 237, 173));
    apply_shimmer(1,1);
}
TEXT_EFFECT(200, 240, 188) {
    apply_gradient(rgb(134, 222, 122), rgb(197, 237, 173));
}

//Basic
TEXT_EFFECT(247, 205, 171) {
    apply_gradient(rgb(247, 205, 171), rgb(217, 171, 134));
}
TEXT_EFFECT(255, 205, 171) {
    apply_gradient(rgb(247, 205, 171), rgb(217, 171, 134));
    apply_shimmer(1,1);
}

//SELECTED
TEXT_EFFECT(27, 224, 66) {
    apply_gradient(rgb(27, 224, 66), rgb(27, 224, 66));
    apply_select_movement(1);
}


// STAR
TEXT_EFFECT(227, 188, 104) {
    apply_gradient(rgb(255, 255, 0), rgb(247, 144, 0));
    apply_shimmer();
    override_shadow_color(rgb(181, 125, 27));


}
// ROYAL
TEXT_EFFECT(63, 174, 186) {
    apply_gradient(rgb(255, 245, 245), rgb(0, 209, 232));
    override_shadow_color(rgb(59, 114, 120));
}


//OG
TEXT_EFFECT(188, 209, 212) {
    apply_gradient(rgb(215, 221, 222), rgb(230, 103, 103));
    apply_fade(rgb(153, 202, 209));
}

//YT

//MYTHIC RANK #df03fc
TEXT_EFFECT(223, 3, 252) {
    apply_gradient(rgb(240, 192, 228), rgb(223, 3, 252));


    apply_fade(rgb(240, 192, 228),3);
    override_shadow_color(rgb(170, 55, 176));

}


TEXT_EFFECT(222, 47, 47) {
    apply_gradient(rgb(255, 255, 255), rgb(222, 47, 47));
    apply_fade(rgb(222, 47, 47));
}

//    apply_vertical_shadow();
//    apply_metalic(rgb(255, 255, 255), rgb(150, 163, 177) * 0.95);
//    override_shadow_color(rgb(70, 70, 100));
//    apply_glowing();
//    apply_fade(rgb(86, 235, 86));
//    apply_blinking();
//    apply_fire();
//    apply_chromatic_abberation();
//    remove_text_shadow();
//    apply_waving_movement();
//    apply_shaking_movement();
//    apply_shimmer();
//    apply_gradient(rgb(255, 235, 120), rgb(255, 82, 82));
//    apply_growing_movement();
//    apply_iterating_movement();
//    apply_thin_outline(rgb(96, 130, 128));